1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/05-c3ty_6dwfk.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
3:I[37457,["/_next/static/chunks/05-c3ty_6dwfk.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
4:I[5234,["/_next/static/chunks/05-c3ty_6dwfk.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/33qztlxtkp21h.js"],"default"]
:HL["/_next/static/chunks/0zvoym2uve75f.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/05-c3ty_6dwfk.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/14mrh2-p_w84d.js","async":true}]],["$","html",null,{"children":["$","body",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}],"notFound":[["$","$L4",null,{}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0zvoym2uve75f.css","precedence":"next"}]]]}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"lMbyly5Qwm6pFf7S6YTGg"}
