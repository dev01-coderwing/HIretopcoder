1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/3ez1cp6l7ddtj.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
3:I[37457,["/_next/static/chunks/3ez1cp6l7ddtj.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
4:I[5234,["/_next/static/chunks/3ez1cp6l7ddtj.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
:HL["/_next/static/chunks/0zvoym2uve75f.css","style"]
5:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}],"notFound":[["$","$L4",null,{}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0zvoym2uve75f.css","precedence":"next"}]]]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W5","buildId":"lMbyly5Qwm6pFf7S6YTGg"}
