:HL["/_next/static/chunks/2nr20jli0ut0h.css","style"]
:HL["/_next/static/chunks/0zvoym2uve75f.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":8,"slots":{"children":{"name":"(user)","param":null,"prefetchHints":20,"slots":{"children":{"name":"contact","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}},"staleTime":300,"buildId":"lMbyly5Qwm6pFf7S6YTGg"}
