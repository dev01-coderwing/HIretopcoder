1:"$Sreact.fragment"
2:I[59427,["/_next/static/chunks/1h-i8n43h3f1s.js","/_next/static/chunks/3ii51mop5a9t7.js","/_next/static/chunks/2mii5_ecstdxy.js","/_next/static/chunks/2jen9u18md93m.js","/_next/static/chunks/0rlf_ebb0dlhx.js","/_next/static/chunks/422c8-vdd2mgh.js","/_next/static/chunks/3xzu3hjg4re7u.js"],"default"]
3:I[97367,["/_next/static/chunks/3ez1cp6l7ddtj.js","/_next/static/chunks/14mrh2-p_w84d.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/422c8-vdd2mgh.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/3xzu3hjg4re7u.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"lMbyly5Qwm6pFf7S6YTGg"}
5:null
