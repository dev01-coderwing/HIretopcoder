1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/3ez1cp6l7ddtj.js","/_next/static/chunks/14mrh2-p_w84d.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"children":"Resource page"}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"lMbyly5Qwm6pFf7S6YTGg"}
4:null
