module.exports=[27823,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28user%29_resources_dedicated-vs-freelancer_page_actions_0nnir4z.js.map