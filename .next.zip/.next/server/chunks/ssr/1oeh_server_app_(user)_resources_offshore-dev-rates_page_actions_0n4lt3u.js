module.exports=[88032,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28user%29_resources_offshore-dev-rates_page_actions_0n4lt3u.js.map