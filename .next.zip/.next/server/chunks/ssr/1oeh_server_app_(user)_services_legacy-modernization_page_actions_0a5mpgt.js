module.exports=[78613,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28user%29_services_legacy-modernization_page_actions_0a5mpgt.js.map