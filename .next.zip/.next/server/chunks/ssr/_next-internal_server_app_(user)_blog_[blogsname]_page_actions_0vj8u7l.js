module.exports=[52375,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_blog_%5Bblogsname%5D_page_actions_0vj8u7l.js.map