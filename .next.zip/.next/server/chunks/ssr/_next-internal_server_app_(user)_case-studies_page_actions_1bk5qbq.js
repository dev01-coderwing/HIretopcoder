module.exports=[99833,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_case-studies_page_actions_1bk5qbq.js.map