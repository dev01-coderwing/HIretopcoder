module.exports=[2434,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_company_page_actions_1i6eojy.js.map