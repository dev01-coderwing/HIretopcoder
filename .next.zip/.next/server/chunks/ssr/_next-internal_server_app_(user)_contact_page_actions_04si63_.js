module.exports=[65645,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_contact_page_actions_04si63_.js.map