module.exports=[38409,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_cookies_page_actions_20pk0m3.js.map