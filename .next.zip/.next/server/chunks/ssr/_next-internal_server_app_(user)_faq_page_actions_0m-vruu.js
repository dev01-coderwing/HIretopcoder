module.exports=[12e3,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_faq_page_actions_0m-vruu.js.map