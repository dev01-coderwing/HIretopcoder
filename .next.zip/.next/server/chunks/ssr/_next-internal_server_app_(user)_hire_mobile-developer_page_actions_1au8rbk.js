module.exports=[88327,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_hire_mobile-developer_page_actions_1au8rbk.js.map