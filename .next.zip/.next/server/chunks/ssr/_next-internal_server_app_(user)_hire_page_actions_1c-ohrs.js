module.exports=[3186,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_hire_page_actions_1c-ohrs.js.map