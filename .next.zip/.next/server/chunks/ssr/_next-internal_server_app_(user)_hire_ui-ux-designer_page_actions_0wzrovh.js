module.exports=[48052,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_hire_ui-ux-designer_page_actions_0wzrovh.js.map