module.exports=[95031,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_privacy_page_actions_16c_gu9.js.map