module.exports=[68432,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_resources_page_actions_00rh46h.js.map