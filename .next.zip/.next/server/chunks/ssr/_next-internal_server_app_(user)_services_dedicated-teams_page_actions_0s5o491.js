module.exports=[3046,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_services_dedicated-teams_page_actions_0s5o491.js.map