module.exports=[72579,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_services_mvp-development_page_actions_0dcnw9x.js.map