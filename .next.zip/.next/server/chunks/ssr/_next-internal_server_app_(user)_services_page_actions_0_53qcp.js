module.exports=[56115,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_services_page_actions_0_53qcp.js.map