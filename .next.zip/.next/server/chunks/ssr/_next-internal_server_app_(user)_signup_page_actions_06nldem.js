module.exports=[31257,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_signup_page_actions_06nldem.js.map