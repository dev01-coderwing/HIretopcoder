module.exports=[66449,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_starthiring_page_actions_1q4j59v.js.map