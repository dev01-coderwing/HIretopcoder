module.exports=[21455,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28user%29_terms_page_actions_0l6hy07.js.map