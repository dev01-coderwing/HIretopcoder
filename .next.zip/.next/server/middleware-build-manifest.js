globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/lMbyly5Qwm6pFf7S6YTGg/_buildManifest.js",
    "static/lMbyly5Qwm6pFf7S6YTGg/_ssgManifest.js",
    "static/lMbyly5Qwm6pFf7S6YTGg/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0iq1i69206cyl.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/07u_h6i539_wj.js",
    "static/chunks/1fupgp9oryyya.js",
    "static/chunks/turbopack-2ikjsaxxyrtc0.js"
  ]
};
